/**
 * @file
 * Global utilities.
 *
 */
(function ($, Drupal) {

  'use strict';

  Drupal.behaviors.barrio_veracruz = {
    attach: function (context, settings) {

    }
  };

})(jQuery, Drupal);
;
